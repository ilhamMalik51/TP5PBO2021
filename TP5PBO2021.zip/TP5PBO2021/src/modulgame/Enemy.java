/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modulgame;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Fauzan
 */
public class Enemy extends GameObject{
    
    private boolean kembali = false;
    
    public Enemy(int x, int y, int speed, ID id){
        super(x, y, id);
        
        vel_y = speed;
    }

    @Override
    public void tick() {
        
        if(kembali == false){
            x += vel_x;
            y += vel_y;
        }else{
            x += vel_x;
            y -= vel_y;
        }
        
        x = Game.clamp(x, 0, Game.WIDTH - 60);
        y = Game.clamp(y, 0, Game.HEIGHT - 80);
        
        if(y == Game.HEIGHT - 80){
            kembali = true;
        }else if(y == 0){ 
            kembali = false;
        }
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.decode("#FF0000"));
        g.fillRect(x, y, 40, 40);
    }
}
