/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modulgame;

import java.util.Random;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.io.IOException;
import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author Fauzan
 */
public class Game extends Canvas implements Runnable{
    Window window;
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    
    private int score = 0;
    private String username;
    private String gameMode;
    private int time;
    private int tempTime;
    private int nItems = 2; //untuk menampung banyak item yang dirender
    private int speed;
    
    private Thread thread;
    private boolean running = false;
    
    private Handler handler;
    
    public enum STATE{
        Game,
        GameOver
    };
    
    public STATE gameState = STATE.Game;
    
    public Game(String v_username, String diff, String mode){
        
        if(mode.equals("Single Player")){
            window = new Window(WIDTH, HEIGHT, "Modul praktikum 5", this);
            handler = new Handler();
            this.addKeyListener(new KeyInput(handler, this));
            
            gameMode = mode;
            
            username = v_username;
            playSound("/Sound.wav");

            if(diff.equals("Easy")){
               time = 20;
               speed = 2;
            }else if(diff.equals("Medium")){
               time = 10;
               speed = 5;
            }else if(diff.equals("Hard")){
               time = 5;
               speed = 20;
            }
        
            tempTime = time;
        
            //ini inisialisasi item pada game
            //player kedua dapat ditambahkan di menu ini
            //musuh dapat ditambahkan pada fungsi ini
            //modfikiasi logika ini
            if(gameState == STATE.Game){
                handler.addObject(new Items(100,150, ID.Item));
                handler.addObject(new Items(200,350, ID.Item));
                handler.addObject(new Player(200,200, ID.Player));
                handler.addObject(new Enemy(150, 0, speed, ID.Enemy));
                handler.addObject(new Enemy(350, 100, speed, ID.Enemy));
                handler.addObject(new Enemy(550, 400, speed, ID.Enemy));

                nItems = 2;
            }
            
        }else if(mode.equals("Multi Player")){
            window = new Window(WIDTH, HEIGHT, "Modul praktikum 5", this);
            handler = new Handler();
            
            this.addKeyListener(new KeyInput(handler, this));
            
            gameMode = mode;
            
            username = v_username;
            playSound("/Sound.wav");

            if(diff.equals("Easy")){
               time = 20;
               speed = 2;
            }else if(diff.equals("Medium")){
               time = 10;
               speed = 5;
            }else if(diff.equals("Hard")){
               time = 5;
               speed = 20;
            }
        
            tempTime = time;
        
            //ini inisialisasi item pada game
            //player kedua dapat ditambahkan di menu ini
            //musuh dapat ditambahkan pada fungsi ini
            //modfikiasi logika ini
            if(gameState == STATE.Game){
                handler.addObject(new Items(100,150, ID.Item));
                handler.addObject(new Items(200,350, ID.Item));
                handler.addObject(new Items(400,150, ID.Item));
                handler.addObject(new Items(500,350, ID.Item));
                handler.addObject(new Player(200,200, ID.Player));
                handler.addObject(new Player2(400,200, ID.Player2));
                handler.addObject(new Enemy(150, 0, speed, ID.Enemy));
                handler.addObject(new Enemy(350, 100, speed, ID.Enemy));
                handler.addObject(new Enemy(550, 400, speed, ID.Enemy));
                nItems = 4;
            }
        }
        
    }

    public synchronized void start(){
        thread = new Thread(this);
        thread.start();
        running = true;
    }
    
    public synchronized void stop(){
        try{
            thread.join();
            running = false;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        
        while(running){
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            
            while(delta >= 1){
                tick();
                delta--;
            }
            if(running){
                render();
                frames++;
            }
            
            if(System.currentTimeMillis() - timer > 1000){
                timer += 1000;
                //System.out.println("FPS: " + frames);
                frames = 0;
                if(gameState == STATE.Game){
                    if(time>0){
                        time--;
                    }else{
                        gameState = STATE.GameOver;
                    }
                }
            }
        }
        stop();
    }
    
    private void tick(){
        handler.tick();
        
        if(gameMode.equals("Single Player")){
            if(gameState == STATE.Game){
            
                GameObject playerObject = null;
                for(int i=0;i< handler.object.size(); i++){
                    if(handler.object.get(i).getId() == ID.Player){
                       playerObject = handler.object.get(i);
                    }
                    
                }

                if(playerObject != null){
                    for(int i=0;i < handler.object.size(); i++){
                        if(handler.object.get(i).getId() == ID.Item){
                            if(checkCollision(playerObject, handler.object.get(i))){
                                playSound("/Eat.wav");
                                handler.removeObject(handler.object.get(i));
                                Random rand = new Random();
                                int rScore = 5 + rand.nextInt(10);
                                int rTime = 1 + rand.nextInt(5);

                                score = score + rScore;
                                time = time + rTime;
                                tempTime = time;
                                nItems = nItems - 1;
                                break;
                            }
                        }
                    }

                    for(int i=0;i < handler.object.size(); i++){
                        if(handler.object.get(i).getId() == ID.Enemy){
                            if(checkLoseToEnemy(playerObject, handler.object.get(i))){
                                gameState = STATE.GameOver;
                                break;
                            }
                        }
                    }

                    //jika item sudah habis maka generate yang baru
                    //letam item dinyatakan random
                    //cara menentukan random adalah dengan menggunakan fungsi random
                    if(nItems == 0){
                        Random rand = new Random();
                        int upperboundX = 600;
                        int upperboundY = 400;

                        int randX = 1 + rand.nextInt(upperboundX);
                        int randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));

                        randX = 1 + rand.nextInt(upperboundX);
                        randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));
                        nItems = 2;
                    }
                }
            }
        }else if(gameMode.equals("Multi Player")){
            if(gameState == STATE.Game){
            
                GameObject playerObject = null;
                GameObject playerObject2 = null;
                for(int i=0;i< handler.object.size(); i++){
                    if(handler.object.get(i).getId() == ID.Player){
                       playerObject = handler.object.get(i);
                    }
                    if(handler.object.get(i).getId() == ID.Player2){
                       playerObject2 = handler.object.get(i);
                    }
                }

                if(playerObject != null && playerObject2 != null){
                    for(int i=0;i < handler.object.size(); i++){
                        if(handler.object.get(i).getId() == ID.Item){
                            if(checkCollision(playerObject, handler.object.get(i)) || checkCollision(playerObject2, handler.object.get(i))){
                                playSound("/Eat.wav");
                                handler.removeObject(handler.object.get(i));
                                Random rand = new Random();
                                int rScore = 5 + rand.nextInt(10);
                                int rTime = 1 + rand.nextInt(5);

                                score = score + rScore;
                                time = time + rTime;
                                tempTime = time;
                                nItems = nItems - 1;
                                break;
                            }
                        }
                    }

                    for(int i=0;i < handler.object.size(); i++){
                        if(handler.object.get(i).getId() == ID.Enemy){
                            if(checkLoseToEnemy(playerObject, handler.object.get(i)) || checkLoseToEnemy(playerObject2, handler.object.get(i))){
                                gameState = STATE.GameOver;
                                break;
                            }
                        }
                    }

                    //jika item sudah habis maka generate yang baru
                    //letam item dinyatakan random
                    //cara menentukan random adalah dengan menggunakan fungsi random
                    if(nItems == 0){
                        Random rand = new Random();
                        int upperboundX = 600;
                        int upperboundY = 400;

                        int randX = 1 + rand.nextInt(upperboundX);
                        int randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));

                        randX = 1 + rand.nextInt(upperboundX);
                        randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));
                        
                        randX = 1 + rand.nextInt(upperboundX);
                        randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));
                        
                        randX = 1 + rand.nextInt(upperboundX);
                        randY = 1 + rand.nextInt(upperboundY);
                        handler.addObject(new Items(randX,randY, ID.Item));
                        nItems = 4;
                    }
                }
            }
        }
        
    }
    
    public static boolean checkCollision(GameObject player, GameObject item){
        boolean result = false;
        
        int sizePlayer = 50;
        int sizeItem = 20;
        
        int playerLeft = player.x;
        int playerRight = player.x + sizePlayer;
        int playerTop = player.y;
        int playerBottom = player.y + sizePlayer;
        
        int itemLeft = item.x;
        int itemRight = item.x + sizeItem;
        int itemTop = item.y;
        int itemBottom = item.y + sizeItem;
        
        if((playerRight > itemLeft ) &&
        (playerLeft < itemRight) &&
        (itemBottom > playerTop) &&
        (itemTop < playerBottom)
        ){
            result = true;
        }
        
        return result;
    }
    
    public static boolean checkLoseToEnemy(GameObject player, GameObject enemy){
        boolean result = false;
        
        int sizePlayer = 50;
        int sizeEnemy = 40;
        
        int playerLeft = player.x;
        int playerRight = player.x + sizePlayer;
        int playerTop = player.y;
        int playerBottom = player.y + sizePlayer;
        
        int enemyLeft = enemy.x;
        int enemyRight = enemy.x + sizeEnemy;
        int enemyTop = enemy.y;
        int enemyBottom = enemy.y + sizeEnemy;
        
        if((playerRight > enemyLeft ) &&
        (playerLeft < enemyRight) &&
        (enemyBottom > playerTop) &&
        (enemyTop < playerBottom)
        ){
            result = true;
        }
        
        return result;
    }
    
    private void render(){
        BufferStrategy bs = this.getBufferStrategy();
        if(bs == null){
            this.createBufferStrategy(3);
            return;
        }
        
        Graphics g = bs.getDrawGraphics();
        
        g.setColor(Color.decode("#F1f3f3"));
        g.fillRect(0, 0, WIDTH, HEIGHT);
                
        
        
        if(gameState ==  STATE.Game){
            handler.render(g);
            
            Font currentFont = g.getFont();
            Font newFont = currentFont.deriveFont(currentFont.getSize() * 1.4F);
            g.setFont(newFont);

            g.setColor(Color.BLACK);
            g.drawString("Score: " +Integer.toString(score), 20, 20);

            g.setColor(Color.BLACK);
            g.drawString("Time: " +Integer.toString(time), WIDTH-120, 20);
            
        }else{
            Font currentFont = g.getFont();
            Font newFont = currentFont.deriveFont(currentFont.getSize() * 3F);
            g.setFont(newFont);

            g.setColor(Color.BLACK);
            g.drawString("GAME OVER", WIDTH/2 - 120, HEIGHT/2 - 30);

            currentFont = g.getFont();
            Font newScoreFont = currentFont.deriveFont(currentFont.getSize() * 0.5F);
            g.setFont(newScoreFont);

            g.setColor(Color.BLACK);
            g.drawString("Score: " +Integer.toString(score+tempTime), WIDTH/2 - 50, HEIGHT/2 - 10);
            
            g.setColor(Color.BLACK);
            g.drawString("Press Space to Continue", WIDTH/2 - 100, HEIGHT/2 + 30);
            
        }
        
        g.dispose();
        bs.show();
    }
    
    public static int clamp(int var, int min, int max){
        if(var >= max){
            return var = max;
        }else if(var <= min){
            return var = min;
        }else{
            return var;
        }
    }
    
    public void close(){
        window.CloseWindow();
    }
    
    public void playSound(String filename){
        try {
            // Open an audio input stream.
            URL url = this.getClass().getResource(filename);
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
            // Get a sound clip resource.
            Clip clip = AudioSystem.getClip();
            // Open audio clip and load samples from the audio input stream.
            clip.open(audioIn);
            clip.start();
            
        } catch (UnsupportedAudioFileException e) {
           e.printStackTrace();
        } catch (IOException e) {
           e.printStackTrace();
        } catch (LineUnavailableException e) {
           e.printStackTrace();
        }
    
    }
    
    public int getScore(){
        return score + tempTime;
    }
    
    public String getUsername(){
        return username;
    }
}
